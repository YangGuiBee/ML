import pandas as pd
import numpy as np

def preprocess(df):
    """
    데이터프레임의 컬럼들을 숫자 형태로 전처리합니다.

    Args:
        df (pandas.DataFrame): 원본 데이터프레임

    Returns:
        pandas.DataFrame: 전처리된 데이터프레임
    """
    # SettingWithCopyWarning을 피하기 위해 데이터프레임 복사
    df_processed = df.copy()

    # 'car_prices_in_rupee'를 'price' (단위: Lakh) 숫자 컬럼으로 변환
    def convert_price_to_lakh(price_str):
        try:
            # 문자열로 변환하고, 양쪽 공백 제거, 소문자로 통일
            price_str = str(price_str).strip().lower()
            price_str = price_str.replace(',', '')

            if 'lakh' in price_str:
                value = float(price_str.replace('lakh', '').strip())
                return value
            elif 'crore' in price_str or 'cr' in price_str:
                value = float(price_str.replace('crore', '').replace('cr', '').strip())
                return value * 100
            else: # 가격 단위가 없는 경우 np.nan 반환
                return np.nan
        except (ValueError, AttributeError):
            return np.nan # 변환 실패 시 NaN 반환

    df_processed['price'] = df_processed['car_prices_in_rupee'].apply(convert_price_to_lakh)

    # 'car_name'에서 'brand' 컬럼 추출
    df_processed['brand'] = df_processed['car_name'].apply(lambda x: x.split(' ')[0])

    # 'kms_driven'을 숫자 컬럼으로 변환
    df_processed['kms_driven'] = df_processed['kms_driven'].str.replace(',', '').str.replace(' kms', '').astype(int)

    # 'engine'을 숫자 컬럼으로 변환
    df_processed['engine'] = df_processed['engine'].str.replace(' cc', '').astype(int)

    # 'Seats'를 숫자 컬럼으로 변환
    df_processed['Seats'] = df_processed['Seats'].str.replace(' Seats', '').astype(int)
    
    # 'ownership'을 숫자 컬럼으로 변환
    df_processed['ownership'] = df_processed['ownership'].str.extract(r'(\d+)').astype(int)

    # 'manufacture'를 숫자 타입으로 명시
    df_processed['year'] = pd.to_numeric(df_processed['manufacture'], errors='coerce')

    # One-hot encoding for categorical features that will be used by ML models
    # Keep the original 'brand', 'fuel_type', 'transmission' columns for visualization
    # 'ownership' is now numerical and excluded from OHE
    categorical_cols_for_ohe = ['fuel_type', 'transmission'] # 'ownership' is now numerical
    df_processed = pd.get_dummies(df_processed, columns=categorical_cols_for_ohe, drop_first=True) # drop_first to avoid multicollinearity

    # 전처리 후 불필요한 원본 컬럼 삭제
    # 'brand' 컬럼은 시각화를 위해 유지
    df_processed = df_processed.drop(columns=['car_prices_in_rupee', 'car_name', 'Unnamed: 0', 'manufacture'])

    # 전처리 후 결측치 확인
    print("\n--- Null values after preprocessing ---")
    print(df_processed.isnull().sum())

    print("\n--- Data Preprocessed Successfully (Ownership as numerical, One-hot encoding applied) ---")
    print(df_processed.head())
    
    return df_processed
