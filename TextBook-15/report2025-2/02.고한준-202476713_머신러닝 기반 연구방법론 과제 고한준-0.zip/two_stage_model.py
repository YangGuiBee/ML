import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, accuracy_score

def run_two_stage_model(df):
    """
    분류-회귀 2단계 모델을 실행하고 평가합니다.
    1. 분류 모델이 가격 구간(100 이상/이하)을 예측합니다.
    2. 예측된 구간에 따라 해당 구간 전용 회귀 모델이 최종 가격을 예측합니다.
    """
    print("\n--- Running Two-Stage (Classification-Regression) Model ---")
    
    # --- 1. 데이터 준비 ---
    # 결측치 제거
    df.dropna(subset=['price'], inplace=True)
    
    # 가격 구간 분류 (0: < 100, 1: >= 100)
    df['price_segment'] = (df['price'] >= 100).astype(int)
    
    # 'brand' 컬럼 원-핫 인코딩
    df_encoded = pd.get_dummies(df, columns=['brand'], drop_first=True)
    
    # 피처(X)와 타겟(y) 분리
    X = df_encoded.drop(['price', 'price_segment'], axis=1)
    y_class = df_encoded['price_segment']
    y_regr = df_encoded['price']
    
    # 학습/테스트 데이터 분리
    X_train, X_test, y_class_train, y_class_test, y_regr_train, y_regr_test = train_test_split(
        X, y_class, y_regr, test_size=0.2, random_state=42, stratify=y_class
    )

    # --- 2. 분류 모델 학습 ---
    print("\nTraining classifier to predict price segment...")
    classifier = RandomForestClassifier(random_state=42)
    classifier.fit(X_train, y_class_train)
    
    # 분류 모델 성능 중간 평가
    y_class_pred = classifier.predict(X_test)
    class_accuracy = accuracy_score(y_class_test, y_class_pred)
    print(f"Classifier Accuracy: {class_accuracy:.4f}")

    # --- 3. 구간별 회귀 모델 학습 ---
    print("Training specialized regressors for each segment...")
    
    # 학습 데이터를 가격 구간에 따라 분리
    X_train_low = X_train[y_regr_train < 100]
    y_train_low = y_regr_train[y_regr_train < 100]
    
    X_train_high = X_train[y_regr_train >= 100]
    y_train_high = y_regr_train[y_regr_train >= 100]
    
    # 저가 구간 회귀 모델 학습
    low_price_regressor = RandomForestRegressor(random_state=42)
    low_price_regressor.fit(X_train_low, y_train_low)
    
    # 고가 구간 회귀 모델 학습
    high_price_regressor = RandomForestRegressor(random_state=42)
    high_price_regressor.fit(X_train_high, y_train_high)

    # --- 4. 각 구간별 모델 성능 평가 (개별) ---
    print("\n--- Evaluating Specialized Regressors on Their Segments ---")
    
    # 낮은 가격 모델 평가
    X_test_low_true = X_test[y_regr_test < 100]
    y_test_low_true = y_regr_test[y_regr_test < 100]
    if not X_test_low_true.empty:
        y_pred_low = low_price_regressor.predict(X_test_low_true)
        low_mae = mean_absolute_error(y_test_low_true, y_pred_low)
        low_rmse = np.sqrt(mean_squared_error(y_test_low_true, y_pred_low))
        low_r2 = r2_score(y_test_low_true, y_pred_low)
        low_results_df = pd.DataFrame([{'Model': 'Low-Price Regressor', 'MAE': low_mae, 'RMSE': low_rmse, 'R2 Score': low_r2}])
        print("\n--- Low-Price Model Evaluation ---")
        print(low_results_df.to_string(index=False))

    # 높은 가격 모델 평가
    X_test_high_true = X_test[y_regr_test >= 100]
    y_test_high_true = y_regr_test[y_regr_test >= 100]
    if not X_test_high_true.empty:
        y_pred_high = high_price_regressor.predict(X_test_high_true)
        high_mae = mean_absolute_error(y_test_high_true, y_pred_high)
        high_rmse = np.sqrt(mean_squared_error(y_test_high_true, y_pred_high))
        high_r2 = r2_score(y_test_high_true, y_pred_high)
        high_results_df = pd.DataFrame([{'Model': 'High-Price Regressor', 'MAE': high_mae, 'RMSE': high_rmse, 'R2 Score': high_r2}])
        print("\n--- High-Price Model Evaluation ---")
        print(high_results_df.to_string(index=False))

    # --- 5. 2단계 예측 수행 (종합) ---
    print("\nMaking final predictions with the two-stage model...")
    test_segments_pred = classifier.predict(X_test)
    y_pred_final = np.zeros(len(X_test))
    
    low_mask = (test_segments_pred == 0)
    high_mask = (test_segments_pred == 1)
    
    if np.any(low_mask):
        y_pred_final[low_mask] = low_price_regressor.predict(X_test[low_mask])
    if np.any(high_mask):
        y_pred_final[high_mask] = high_price_regressor.predict(X_test[high_mask])

    # --- 6. 최종 성능 평가 (종합) ---
    mae = mean_absolute_error(y_regr_test, y_pred_final)
    rmse = np.sqrt(mean_squared_error(y_regr_test, y_pred_final))
    r2 = r2_score(y_regr_test, y_pred_final)
    
    results = {
        'Model': 'Two-Stage Model (Combined)',
        'MAE': mae,
        'RMSE': rmse,
        'R2 Score': r2
    }
    results_df = pd.DataFrame([results])
    
    print("\n--- Two-Stage Model Combined Evaluation Results ---")
    print(results_df.to_string(index=False))
