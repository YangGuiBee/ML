import warnings
from data_loader import load_and_inspect_data
from preprocessor import preprocess
from dataset_creator import create_dataset
from model_trainer import (
    train_linear_regression,
    train_decision_tree,
    train_random_forest
)
from evaluator import evaluate_models, visualize_evaluation_results
from hyperparameter_tuner import tune_decision_tree, tune_random_forest
from two_stage_model import run_two_stage_model
from visualizer import create_visualizations, create_scatter_plots_by_brand

def main():
    """
    데이터를 로드, 전처리, 모델 학습, 평가, 하이퍼파라미터 튜닝, 그리고 시각화를 수행하는 메인 함수
    """
    warnings.filterwarnings('ignore')
    
    # 1. 데이터 로드 및 확인
    file_path = 'data/car_price.csv'
    df = load_and_inspect_data(file_path)
    
    if df is not None:
        # 2. 데이터 전처리
        df_processed = preprocess(df.copy())

        # 3. 모델 학습용 데이터셋 생성
        X_train, X_test, y_train, y_test = create_dataset(df_processed.copy())

        # 4. 기본 모델 학습
        lr_model = train_linear_regression(X_train, y_train)
        dt_model = train_decision_tree(X_train, y_train)
        rf_model = train_random_forest(X_train, y_train)

        base_models = {
            'Linear Regression': lr_model,
            'Decision Tree': dt_model,
            'Random Forest': rf_model
        }

        # 5. 기본 모델 평가
        print("\n--- Base Model Evaluation ---")
        evaluate_models(base_models, X_test, y_test)
        visualize_evaluation_results(base_models, X_test, y_test)

        # 6. 하이퍼파라미터 튜닝
        tuned_dt_model = tune_decision_tree(X_train, y_train)
        tuned_rf_model = tune_random_forest(X_train, y_train)

        tuned_models = {
            'Linear Regression': lr_model, # 선형 회귀는 튜닝하지 않으므로 그대로 사용
            'Tuned Decision Tree': tuned_dt_model,
            'Tuned Random Forest': tuned_rf_model
        }
        
        # 7. 튜닝된 모델 평가
        print("\n--- Tuned Model Evaluation ---")
        evaluate_models(tuned_models, X_test, y_test)
        visualize_evaluation_results(tuned_models, X_test, y_test)

        # 8. 2단계 모델 실행 및 평가
        run_two_stage_model(df_processed.copy())

        # 9. 데이터 시각화
        print("\n--- Data Visualizations ---")
        create_visualizations(df_processed)
        create_scatter_plots_by_brand(df_processed)

if __name__ == '__main__':
    main()
