import pandas as pd

def load_and_inspect_data(file_path):
    """
    CSV 파일을 로드하고 데이터의 기본 정보를 출력합니다.

    Args:
        file_path (str): CSV 파일의 경로

    Returns:
        pandas.DataFrame: 로드된 데이터프레임
    """
    df = pd.read_csv(file_path)

    print("Data loaded successfully.")
    print("--- First 5 rows ---")
    print(df.head())
    print("\n--- Data Info ---")
    df.info()
    print("\n--- Descriptive Statistics ---")
    print(df.describe())
    
    return df
