from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor

def train_linear_regression(X_train, y_train):
    """
    선형 회귀 모델을 학습시킵니다.
    """
    model = LinearRegression()
    model.fit(X_train, y_train)
    print("Linear Regression model trained.")
    return model

def train_decision_tree(X_train, y_train):
    """
    의사결정 트리 회귀 모델을 학습시킵니다.
    """
    model = DecisionTreeRegressor(random_state=42)
    model.fit(X_train, y_train)
    print("Decision Tree Regressor model trained.")
    return model

def train_random_forest(X_train, y_train):
    """
    랜덤 포레스트 회귀 모델을 학습시킵니다.
    """
    model = RandomForestRegressor(random_state=42, n_estimators=100)
    model.fit(X_train, y_train)
    print("Random Forest Regressor model trained.")
    return model
