from sklearn.model_selection import GridSearchCV
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor

def tune_decision_tree(X_train, y_train):
    """
    GridSearchCV를 사용하여 의사결정 트리 모델의 최적 하이퍼파라미터를 찾습니다.
    """
    param_grid = {
        'max_depth': [10, 20, 30, None],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4]
    }
    
    grid_search = GridSearchCV(
        estimator=DecisionTreeRegressor(random_state=42),
        param_grid=param_grid,
        cv=5,
        n_jobs=-1,
        scoring='neg_mean_squared_error',
        verbose=1
    )
    
    print("\nTuning Decision Tree Regressor...")
    grid_search.fit(X_train, y_train)
    
    print(f"Best parameters for Decision Tree: {grid_search.best_params_}")
    return grid_search.best_estimator_

def tune_random_forest(X_train, y_train):
    """
    GridSearchCV를 사용하여 랜덤 포레스트 모델의 최적 하이퍼파라미터를 찾습니다.
    (계산 시간이 길어질 수 있으므로, 파라미터 그리드를 간소화합니다.)
    """
    param_grid = {
        'n_estimators': [100, 200],
        'max_depth': [10, 20, None],
        'min_samples_split': [2, 5],
        'min_samples_leaf': [1, 2]
    }
    
    grid_search = GridSearchCV(
        estimator=RandomForestRegressor(random_state=42),
        param_grid=param_grid,
        cv=3, # CV 폴드를 3으로 줄여 시간 단축
        n_jobs=-1,
        scoring='neg_mean_squared_error',
        verbose=1
    )
    
    print("\nTuning Random Forest Regressor...")
    grid_search.fit(X_train, y_train)
    
    print(f"Best parameters for Random Forest: {grid_search.best_params_}")
    return grid_search.best_estimator_
