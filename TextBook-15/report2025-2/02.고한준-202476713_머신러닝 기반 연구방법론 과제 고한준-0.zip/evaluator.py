import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import matplotlib.pyplot as plt
import seaborn as sns

def evaluate_models(models, X_test, y_test):
    """
    학습된 모델들의 성능을 평가하고 결과를 표로 출력합니다.

    Args:
        models (dict): 모델 이름과 학습된 모델 객체를 담은 딕셔너리
        X_test (pd.DataFrame): 테스트용 피처 데이터
        y_test (pd.Series): 테스트용 타겟 데이터
    """
    results = []
    
    for name, model in models.items():
        # 예측 수행
        y_pred = model.predict(X_test)
        
        # 평가지표 계산
        mae = mean_absolute_error(y_test, y_pred)
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        r2 = r2_score(y_test, y_pred)
        
        results.append({
            'Model': name,
            'MAE': mae,
            'RMSE': rmse,
            'R2 Score': r2
        })

    # 결과를 데이터프레임으로 변환하여 출력
    results_df = pd.DataFrame(results)
    
    print("\n--- Model Evaluation Results ---")
    print(results_df.to_string(index=False))

def visualize_evaluation_results(models, X_test, y_test):
    """
    모델 평가 결과를 시각화합니다 (Actual vs. Predicted).

    Args:
        models (dict): 모델 이름과 학습된 모델 객체를 담은 딕셔너리
        X_test (pd.DataFrame): 테스트용 피처 데이터
        y_test (pd.Series): 테스트용 타겟 데이터
    """
    num_models = len(models)
    fig, axes = plt.subplots(1, num_models, figsize=(6 * num_models, 5))
    fig.suptitle('Model Evaluation: Actual vs. Predicted Values', fontsize=16)

    # axes가 1개일 경우 배열로 만들기
    if num_models == 1:
        axes = [axes]

    model_items = list(models.items())

    for i in range(num_models):
        name = model_items[i][0]
        model = model_items[i][1]
        ax = axes[i]
        
        # 예측 수행
        y_pred = model.predict(X_test)
        
        # 산점도 생성
        sns.scatterplot(ax=ax, x=y_test, y=y_pred, alpha=0.5)
        
        # y=x 기준선 추가
        lims = [
            np.min([ax.get_xlim(), ax.get_ylim()]),  # min of both axes
            np.max([ax.get_xlim(), ax.get_ylim()]),  # max of both axes
        ]
        ax.plot(lims, lims, 'r--', alpha=0.75, zorder=0)
        
        ax.set_title(name)
        ax.set_xlabel('Actual Price (in Lakh)')
        ax.set_ylabel('Predicted Price (in Lakh)')
        ax.set_aspect('equal', adjustable='box')

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()