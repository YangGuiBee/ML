import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def create_visualizations(df):
    """
    데이터프레임을 사용하여 주요 데이터 시각화를 하나의 프레임에 생성합니다.

    Args:
        df (pandas.DataFrame): 시각화할 데이터프레임
    """
    # 3x2 서브플롯 프레임 생성
    fig, axes = plt.subplots(3, 2, figsize=(20, 18))
    fig.suptitle('Car Price Data Visualizations', fontsize=20)

    # 1. 가격 분포 시각화 (첫 번째 서브플롯)
    sns.histplot(ax=axes[0, 0], data=df, x='price', bins=30, kde=True)
    axes[0, 0].set_title('Price Distribution')
    axes[0, 0].set_xlabel('Price (in Lakh)')
    axes[0, 0].set_ylabel('Frequency')

    # 2. 연식에 따른 가격 시각화 (두 번째 서브플롯)
    sns.boxplot(ax=axes[0, 1], data=df.sort_values('year'), x='year', y='price')
    axes[0, 1].set_title('Price by Year')
    axes[0, 1].set_xlabel('Year')
    axes[0, 1].set_ylabel('Price (in Lakh)')
    axes[0, 1].tick_params(axis='x', rotation=45)

    # 3. 브랜드별 평균 가격 시각화 (세 번째 서브플롯)
    # 브랜드가 너무 많으면 상위 20개만 표시
    top_brands = df['brand'].value_counts().nlargest(20).index
    df_top_brands = df[df['brand'].isin(top_brands)]
    
    brand_order = df_top_brands.groupby('brand')['price'].mean().sort_values(ascending=False).index
    sns.barplot(ax=axes[1, 0], data=df_top_brands, x='brand', y='price', estimator=np.mean, order=brand_order)
    axes[1, 0].set_title('Average Price by Top 20 Brands')
    axes[1, 0].set_xlabel('Brand')
    axes[1, 0].set_ylabel('Average Price (in Lakh)')
    axes[1, 0].tick_params(axis='x', rotation=45)
    
    # 4. 연식, 가격, 브랜드 관계 산점도 (네 번째 서브플롯)
    sns.scatterplot(ax=axes[1, 1], data=df_top_brands, x='year', y='price', hue='brand', alpha=0.6)
    axes[1, 1].set_title('Price vs. Year by Brand (Top 20)')
    axes[1, 1].set_xlabel('Year')
    axes[1, 1].set_ylabel('Price (in Lakh)')
    axes[1, 1].legend().set_visible(False) # 범례가 너무 많아 복잡해지므로 숨김

    # 5. 숫자형 변수 간 상관관계 히트맵 (다섯 번째 서브플롯)
    numerical_cols = ['price', 'year', 'kms_driven', 'engine', 'Seats', 'ownership']
    corr_matrix = df[numerical_cols].corr()
    sns.heatmap(ax=axes[2, 0], data=corr_matrix, annot=True, cmap='coolwarm', fmt=".2f")
    axes[2, 0].set_title('Correlation Matrix of Numerical Features')

    # 6. 연식, 가격, 주행거리 관계 산점도 (여섯 번째 서브플롯)
    sns.scatterplot(ax=axes[2, 1], data=df, x='year', y='price', hue='kms_driven', palette='viridis', alpha=0.6)
    axes[2, 1].set_title('Price vs. Year, Colored by Kms Driven')
    axes[2, 1].set_xlabel('Year')
    axes[2, 1].set_ylabel('Price (in Lakh)')

    # 레이아웃 조정 및 플롯 표시
    plt.tight_layout(rect=[0, 0.03, 1, 0.95]) # suptitle 과 겹치지 않도록 조정
    plt.show()

def create_scatter_plots_by_brand(df):
    """
    상위 6개 브랜드 각각에 대해 가격, 연식, 주행거리를 보여주는
    산점도 서브플롯을 생성합니다.
    """
    # 상위 6개 브랜드 찾기
    top_6_brands = df['brand'].value_counts().nlargest(6).index

    # 3x2 서브플롯 프레임 생성
    fig, axes = plt.subplots(3, 2, figsize=(20, 18))
    fig.suptitle('Price vs. Year (Size by Kms Driven) for Top 6 Brands', fontsize=20)
    axes = axes.flatten() # 2D 배열을 1D로 만들어 쉽게 순회

    # 각 브랜드별로 서브플롯 생성
    for i, brand_name in enumerate(top_6_brands):
        ax = axes[i]
        df_brand = df[df['brand'] == brand_name]
        
        sns.scatterplot(
            ax=ax,
            data=df_brand,
            x='year',
            y='price',
            size='kms_driven',
            sizes=(20, 200),
            alpha=0.7,
            hue='kms_driven', # 색상도 주행거리에 따라
            palette='viridis'
        )
        
        ax.set_title(f'Brand: {brand_name}')
        ax.set_xlabel('Year')
        ax.set_ylabel('Price (in Lakh)')
        ax.legend().set_visible(False) # 각 서브플롯의 범례는 숨김

    # 레이아웃 조정 및 플롯 표시
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()
