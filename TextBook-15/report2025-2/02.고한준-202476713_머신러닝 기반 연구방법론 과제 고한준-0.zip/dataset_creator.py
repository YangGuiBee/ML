import pandas as pd
from sklearn.model_selection import train_test_split

def create_dataset(df):
    """
    전처리된 데이터프레임을 받아 모델 학습을 위한 데이터셋을 생성합니다.

    Args:
        df (pandas.DataFrame): 전처리된 데이터프레임

    Returns:
        tuple: X_train, X_test, y_train, y_test
    """
    # 'price' 컬럼에 결측치가 있는 행 제거
    df.dropna(subset=['price'], inplace=True)
    
    # 'brand' 컬럼 원-핫 인코딩
    df_encoded = pd.get_dummies(df, columns=['brand'], drop_first=True)

    # 피처(X)와 타겟(y) 분리
    X = df_encoded.drop('price', axis=1)
    y = df_encoded['price']

    # 학습용/테스트용 데이터 분리
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    print("\n--- Dataset created for modeling ---")
    print(f"Training set size: {len(X_train)} samples")
    print(f"Testing set size: {len(X_test)} samples")

    return X_train, X_test, y_train, y_test
