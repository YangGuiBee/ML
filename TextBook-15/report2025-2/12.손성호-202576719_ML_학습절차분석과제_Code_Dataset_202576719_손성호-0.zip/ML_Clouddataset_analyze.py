import numpy as np                           # 수치 계산
import pandas as pd                          # 데이터프레임 처리
import matplotlib.pyplot as plt              # EDA 시각화

from sklearn.model_selection import train_test_split, GridSearchCV  # 데이터 분리, 튜닝
from sklearn.ensemble import RandomForestClassifier                 # ML 모델 (랜덤포레스트)
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score  # 성능 지표

import xlsxwriter  # 엑셀 차트 생성을 위한 엔진 (pandas에서 사용)


CSV_PATH = "cloud_dataset.csv"                 # 입력 CSV 파일 경로
EXCEL_OUTPUT = "cloud_anomaly_results.xlsx"    # 산출 엑셀 파일 경로
RANDOM_STATE = 42                              # 재현성을 위한 시드

TARGET_COL = "Anomaly_Label"                   # 타깃 컬럼 (0=정상, 1=이상)
NUMERIC_FEATURE_COLS = [                       # 수치형 피처
    "CPU_Usage",
    "Memory_Usage",
    "Disk_IO",
    "Network_IO",
]
CATEGORICAL_COLS = ["Workload_Type"]           # 범주형 피처


# (1) 데이터 로드
def load_data(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path)                # CSV → DataFrame
    return df


# (2) 시각화(EDA)
def run_eda(df: pd.DataFrame) -> None:
    # 1) 수치형 분포 히스토그램
    try:
        df[NUMERIC_FEATURE_COLS].hist(bins=30, figsize=(10, 8))
        plt.suptitle("Numeric Feature Distributions")
        plt.tight_layout()
        plt.savefig("eda_hist.jpg", dpi=150, bbox_inches="tight")
        plt.close()
    except Exception as e:
        print(f"[WARN] 히스토그램 생성 중 오류: {e}")

    # 2) 수치형 피처 상관관계 행렬
    try:
        corr = df[NUMERIC_FEATURE_COLS].corr()
        plt.figure(figsize=(6, 5))
        plt.imshow(corr, interpolation="nearest")
        plt.colorbar()
        plt.xticks(range(len(corr.columns)), corr.columns, rotation=45)
        plt.yticks(range(len(corr.index)), corr.index)
        plt.title("Numeric Feature Correlation")
        plt.tight_layout()
        plt.savefig("eda_corr.jpg", dpi=150, bbox_inches="tight")
        plt.close()
    except Exception as e:
        print(f"상관관계 시각화 중 오류: {e}")

    # 3) Timestamp 기준 CPU 시계열
    if "Timestamp" in df.columns:
        try:
            df_sorted = df.copy()
            df_sorted["Timestamp"] = pd.to_datetime(df_sorted["Timestamp"])
            df_sorted = df_sorted.sort_values("Timestamp")

            plt.figure(figsize=(10, 4))
            plt.plot(df_sorted["Timestamp"], df_sorted["CPU_Usage"])
            plt.title("CPU_Usage over time")
            plt.xlabel("Time")
            plt.ylabel("CPU_Usage")
            plt.tight_layout()
            plt.savefig("eda_cpu_time.jpg", dpi=150, bbox_inches="tight")
            plt.close()
        except Exception as e:
            print(f"[WARN] Timestamp 기반 시계열 그래프 생성 중 오류: {e}")

# (3) ML 문제 정의 & (4) Train/Test 분리
def prepare_dataset(df: pd.DataFrame):
    if TARGET_COL not in df.columns:
        raise ValueError(f"TARGET_COL '{TARGET_COL}' not in DataFrame")

    missing_num = [c for c in NUMERIC_FEATURE_COLS if c not in df.columns]
    if missing_num:
        raise ValueError(f"Missing numeric columns: {missing_num}")

    missing_cat = [c for c in CATEGORICAL_COLS if c not in df.columns]
    if missing_cat:
        raise ValueError(f"Missing categorical columns: {missing_cat}")

    X_num = df[NUMERIC_FEATURE_COLS].copy()                        # 수치형 피처
    X_cat = pd.get_dummies(df[CATEGORICAL_COLS], drop_first=True)  # 범주형 원-핫 인코딩
    X = pd.concat([X_num, X_cat], axis=1)                          # 최종 입력 X
    y = df[TARGET_COL].copy()                                      # 타깃 y

    X_train, X_test, y_train, y_test = train_test_split(           # Train/Test 분리
        X,
        y,
        test_size=0.2,
        random_state=RANDOM_STATE,
        stratify=y,                                                # 이상 비율 유지
    )
    return X_train, X_test, y_train, y_test


# (5) Baseline 모델 학습
def train_baseline_model(X_train, y_train) -> RandomForestClassifier:
    model = RandomForestClassifier(
        n_estimators=100,
        random_state=RANDOM_STATE,
        n_jobs=-1,
        class_weight="balanced",
    )  # 기본 RandomForest 설정
    model.fit(X_train, y_train)  # 학습 수행
    return model


# (6) / (8) 모델 평가
def evaluate_model(model, X_test, y_test, label: str):
    y_pred = model.predict(X_test)                                      # 클래스 예측
    y_proba = (                                                         # 이상(1) 확률
        model.predict_proba(X_test)[:, 1]
        if hasattr(model, "predict_proba")
        else None
    )

    report_dict = classification_report(y_test, y_pred, output_dict=True)  # dict 리포트
    cm = confusion_matrix(y_test, y_pred)                                  # 혼동 행렬
    roc = roc_auc_score(y_test, y_proba) if y_proba is not None else None  # ROC-AUC

    return {
        "label": label,              # Baseline / Optimized 구분
        "y_true": y_test,            # 실제 라벨
        "y_pred": y_pred,            # 예측 라벨
        "y_proba": y_proba,          # 예측 확률
        "report_dict": report_dict,  # 분류 리포트
        "confusion_matrix": cm,      # 혼동 행렬
        "roc_auc": roc,              # ROC-AUC 점수
    }


# (7) 하이퍼파라미터 튜닝
def tune_model(X_train, y_train) -> RandomForestClassifier:
    base_model = RandomForestClassifier(
        random_state=RANDOM_STATE,
        n_jobs=-1,
        class_weight="balanced",
    )  # 기준 모델

    param_grid = {                         # 탐색할 하이퍼파라미터
        "n_estimators": [100, 200],
        "max_depth": [None, 5, 10],
        "min_samples_split": [2, 5],
        "min_samples_leaf": [1, 2],
    }

    grid_search = GridSearchCV(
        estimator=base_model,
        param_grid=param_grid,
        cv=3,
        scoring="f1",   # 이상(1)에 민감한 F1 기준
        n_jobs=-1,
        verbose=0,
    )

    grid_search.fit(X_train, y_train)             # Train 데이터로 튜닝
    best_model = grid_search.best_estimator_      # 최적 모델
    return best_model


# (9) 엑셀 리포트 생성 (단일 시트 + 차트)
def make_excel_report(
    df: pd.DataFrame,
    baseline_result: dict,
    optimized_result: dict,
    output_path: str,
) -> None:
    # ----- 1. Dataset Summary -----
    total_rows = len(df)                              # 전체 행 수
    label_counts = df[TARGET_COL].value_counts()      # 라벨별 개수
    normal_count = label_counts.get(0, 0)             # 정상 수
    anomaly_count = label_counts.get(1, 0)            # 이상 수
    anomaly_ratio = anomaly_count / total_rows if total_rows > 0 else 0.0  # 이상 비율

    dataset_summary_df = pd.DataFrame(                # 데이터셋 요약 테이블
        [
            {"항목": "총 샘플 수", "값": total_rows},
            {"항목": "정상(0) 샘플 수", "값": normal_count},
            {"항목": "이상(1) 샘플 수", "값": anomaly_count},
            {"항목": "이상 비율", "값": anomaly_ratio},
        ]
    )

    # ----- 2. Numeric Feature Statistics -----
    feature_stats_df = df[NUMERIC_FEATURE_COLS].describe().T  # 수치형 describe
    feature_stats_df.reset_index(inplace=True)
    feature_stats_df.rename(columns={"index": "Feature"}, inplace=True)

    # 여기서 사분위수 컬럼 이름 변경
    feature_stats_df.rename(
        columns={
            "25%": "Q1(25%)",
            "50%": "Q2(50%, Median)",
            "75%": "Q3(75%)",
        },
        inplace=True,
    )

    # ----- 3. Model Results Summary (Baseline vs Optimized) -----
    def build_metrics_row(result_dict: dict, model_name: str) -> dict:
        report = result_dict["report_dict"]               # classification_report dict
        roc = result_dict["roc_auc"]                      # ROC-AUC
        accuracy = report.get("accuracy", np.nan)         # 전체 정확도

        cls1 = report.get("1", {})                        # 클래스 1(이상)에 대한 지표
        precision_1 = cls1.get("precision", np.nan)
        recall_1 = cls1.get("recall", np.nan)
        f1_1 = cls1.get("f1-score", np.nan)

        return {
            "모델": model_name,
            "Accuracy(정확도)": accuracy,
            "Precision_1(이상 정밀도)": precision_1,
            "Recall_1(이상 재현율)": recall_1,
            "F1_1(이상 F1)": f1_1,
            "ROC_AUC": roc,
        }

    baseline_metrics_row = build_metrics_row(baseline_result, "Baseline_RF")
    optimized_metrics_row = build_metrics_row(optimized_result, "Optimized_RF")
    model_results_df = pd.DataFrame([baseline_metrics_row, optimized_metrics_row])

    # ----- 4. Classification Report 상세 -----
    def report_dict_to_df(report_dict: dict, model_name: str) -> pd.DataFrame:
        rows = []
        for key, value in report_dict.items():
            if isinstance(value, dict):                   # 클래스별 / 평균 항목
                row = {"model": model_name, "label": key}
                row.update(value)
                rows.append(row)
            else:                                         # accuracy 단일 값
                rows.append(
                    {
                        "model": model_name,
                        "label": "accuracy",
                        "precision": np.nan,
                        "recall": np.nan,
                        "f1-score": np.nan,
                        "support": np.nan,
                        "accuracy": value,
                    }
                )
        return pd.DataFrame(rows)

    baseline_report_df = report_dict_to_df(baseline_result["report_dict"], "Baseline_RF")
    optimized_report_df = report_dict_to_df(optimized_result["report_dict"], "Optimized_RF")
    classification_report_df = pd.concat([baseline_report_df, optimized_report_df], ignore_index=True)

    # ----- 5. Confusion Matrices -----
    def build_cm_df(result_dict: dict, model_name: str) -> pd.DataFrame:
        cm = result_dict["confusion_matrix"]
        cm_df = pd.DataFrame(
            cm,
            columns=["Pred_정상(0)", "Pred_이상(1)"],
            index=["True_정상(0)", "True_이상(1)"],
        )
        cm_df.index.name = f"{model_name}_Confusion_Matrix"
        return cm_df


    cm_baseline_df = build_cm_df(baseline_result, "Baseline_RF")
    cm_optimized_df = build_cm_df(optimized_result, "Optimized_RF")

    # ----- 엑셀 작성 (Report 시트 하나) -----
    with pd.ExcelWriter(output_path, engine="xlsxwriter") as writer:
        workbook = writer.book
        worksheet = workbook.add_worksheet("Report")
        writer.sheets["Report"] = worksheet

        col_widths = {}                                   # 열 너비 캐시

        def update_col_widths(df_local: pd.DataFrame, start_col: int):
            for i, col in enumerate(df_local.columns):
                col_idx = start_col + i
                col_header = str(col)
                max_len = len(col_header)
                for val in df_local[col]:
                    length = len(str(val)) if not pd.isna(val) else 0
                    max_len = max(max_len, length)
                col_widths[col_idx] = max(col_widths.get(col_idx, 0), max_len + 2)

        title_format = workbook.add_format({"bold": True})
        row = 0

        # 1) 제목
        main_title = "Cloud Anomaly Detection – ML Report"
        worksheet.write(row, 0, main_title, title_format)
        col_widths[0] = max(col_widths.get(0, 0), len(main_title) + 2)
        row += 2

        # 2) Dataset Summary
        dataset_title_row = row
        worksheet.write(dataset_title_row, 0, "1. Dataset Summary", title_format)
        col_widths[0] = max(col_widths[0], len("1. Dataset Summary") + 2)
        dataset_table_row = dataset_title_row + 1
        dataset_summary_df.to_excel(writer, "Report", startrow=dataset_table_row, startcol=0, index=False)
        update_col_widths(dataset_summary_df, 0)
        row = dataset_table_row + len(dataset_summary_df) + 2

        # 3) Numeric Feature Statistics
        feature_title_row = row
        worksheet.write(feature_title_row, 0, "2. Numeric Feature Statistics (describe)", title_format)
        col_widths[0] = max(col_widths[0], len("2. Numeric Feature Statistics (describe)") + 2)
        feature_table_row = feature_title_row + 1
        feature_stats_df.to_excel(writer, "Report", startrow=feature_table_row, startcol=0, index=False)
        update_col_widths(feature_stats_df, 0)
        row = feature_table_row + len(feature_stats_df) + 2

        # 4) Model Results Summary
        metrics_title_row = row
        worksheet.write(metrics_title_row, 0, "3. ML Model Results Summary (Baseline vs Optimized)", title_format)
        col_widths[0] = max(col_widths[0], len("3. ML Model Results Summary (Baseline vs Optimized)") + 2)
        metrics_table_row = metrics_title_row + 1
        model_results_df.to_excel(writer, "Report", startrow=metrics_table_row, startcol=0, index=False)
        update_col_widths(model_results_df, 0)
        row = metrics_table_row + len(model_results_df) + 2

        # 5) Confusion Matrices
        cm_title_row = row
        worksheet.write(cm_title_row, 0, "4. Confusion Matrices", title_format)
        col_widths[0] = max(col_widths[0], len("4. Confusion Matrices") + 2)
        cm_baseline_row = cm_title_row + 1
        cm_baseline_df.to_excel(writer, "Report", startrow=cm_baseline_row, startcol=0)
        update_col_widths(cm_baseline_df.reset_index(), 0)
        cm_optimized_row = cm_baseline_row + cm_baseline_df.shape[0] + 4
        cm_optimized_df.to_excel(writer, "Report", startrow=cm_optimized_row, startcol=0)
        update_col_widths(cm_optimized_df.reset_index(), 0)
        row = cm_optimized_row + cm_optimized_df.shape[0] + 2

        # 6) Classification Report
        cr_title_row = row
        worksheet.write(cr_title_row, 0, "5. Classification Report (Baseline & Optimized)", title_format)
        col_widths[0] = max(col_widths[0], len("5. Classification Report (Baseline & Optimized)") + 2)
        cr_table_row = cr_title_row + 1
        classification_report_df.to_excel(writer, "Report", startrow=cr_table_row, startcol=0, index=False)
        update_col_widths(classification_report_df, 0)

        # ----- 차트 1: 총 샘플 / 정상 / 이상 Count -----
        chart_label = workbook.add_chart({"type": "column"})

        # dataset_summary_df는 dataset_table_row부터 쓰였고,
        # dataset_table_row 행에는 헤더(항목, 값),
        # 그 아래부터 실제 데이터가 들어가 있습니다.
        first_data_row = dataset_table_row + 1  # "총 샘플 수"
        last_data_row = dataset_table_row + 3   # "이상(1) 샘플 수"까지

        chart_label.add_series(
            {
                "name": "Sample Count",
                "categories": ["Report", first_data_row, 0, last_data_row, 0],  # 항목 열
                "values": ["Report", first_data_row, 1, last_data_row, 1],      # 값 열
            }
        )
        chart_label.set_title({"name": "Total / Normal / Anomaly Count"})
        chart_label.set_x_axis({"name": "항목"})
        chart_label.set_y_axis({"name": "Count"})
        chart_label.set_legend({"position": "none"})
        worksheet.insert_chart(1, 9, chart_label)

        # ----- 차트 2: Numeric Feature Summary (min/mean/max) -----
        chart_feat = workbook.add_chart({"type": "column"})

        # feature_stats_df는 다음과 같은 컬럼을 가정:
        # ["Feature", "count", "mean", "std", "min", "25%", "50%", "75%", "max"]
        feat_first_row = feature_table_row + 1
        feat_last_row = feature_table_row + len(feature_stats_df)

        feature_col_idx = 0
        min_col_idx = feature_stats_df.columns.get_loc("min")
        mean_col_idx = feature_stats_df.columns.get_loc("mean")
        max_col_idx = feature_stats_df.columns.get_loc("max")

        # min, mean, max 세 개를 한 차트에 시리즈로 추가
        for series_name, col_idx in [
            ("min", min_col_idx),
            ("mean", mean_col_idx),
            ("max", max_col_idx),
        ]:
            chart_feat.add_series(
                {
                    "name": series_name,
                    "categories": ["Report", feat_first_row, feature_col_idx,
                                   feat_last_row, feature_col_idx],
                    "values": ["Report", feat_first_row, col_idx,
                               feat_last_row, col_idx],
                }
            )

        chart_feat.set_title({"name": "Numeric Feature Summary (min / mean / max)"})
        chart_feat.set_x_axis({"name": "Feature"})
        chart_feat.set_y_axis({"name": "Value"})
        chart_feat.set_legend({"position": "bottom"})
        worksheet.insert_chart(16, 9, chart_feat)


        # ----- 차트 3: Baseline vs Optimized Metrics -----
        chart_metrics = workbook.add_chart({"type": "column"})
        metrics_header_row = metrics_table_row
        metrics_data_start_row = metrics_table_row + 1
        metrics_first_col = 1
        metrics_last_col = len(model_results_df.columns) - 1
        chart_metrics.add_series(
            {
                "name": ["Report", metrics_data_start_row, 0],  # Baseline
                "categories": ["Report", metrics_header_row, metrics_first_col,
                               metrics_header_row, metrics_last_col],
                "values": ["Report", metrics_data_start_row, metrics_first_col,
                           metrics_data_start_row, metrics_last_col],
            }
        )
        chart_metrics.add_series(
            {
                "name": ["Report", metrics_data_start_row + 1, 0],  # Optimized
                "categories": ["Report", metrics_header_row, metrics_first_col,
                               metrics_header_row, metrics_last_col],
                "values": ["Report", metrics_data_start_row + 1, metrics_first_col,
                           metrics_data_start_row + 1, metrics_last_col],
            }
        )
        chart_metrics.set_title({"name": "Baseline vs Optimized Metrics"})
        chart_metrics.set_x_axis({"name": "Metric"})
        chart_metrics.set_y_axis({"name": "Value"})
        chart_metrics.set_legend({"position": "bottom"})
        worksheet.insert_chart(31, 9, chart_metrics)

        # 열 너비 오토핏 (대략)
        for col_idx, width in col_widths.items():
            worksheet.set_column(col_idx, col_idx, min(width, 40))  # 최대 폭 40 제한


def main():
    df = load_data(CSV_PATH)                                              # (1) 데이터 로드
    run_eda(df)                                                           # (2) 시각화(EDA)
    X_train, X_test, y_train, y_test = prepare_dataset(df)                # (3)(4) 전처리 + 분리
    baseline_model = train_baseline_model(X_train, y_train)               # (5) Baseline 학습
    baseline_result = evaluate_model(baseline_model, X_test, y_test, "Baseline")   # (6) 평가
    best_model = tune_model(X_train, y_train)                             # (7) 최적화
    optimized_result = evaluate_model(best_model, X_test, y_test, "Optimized")     # (8) 재평가
    make_excel_report(df, baseline_result, optimized_result, EXCEL_OUTPUT)         # (9) 엑셀 리포트


if __name__ == "__main__":
    main()
